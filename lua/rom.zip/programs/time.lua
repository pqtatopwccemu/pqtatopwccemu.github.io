local nTime = os.time()
local nDay = os.day()
print( "The time is "..textutils.formatTime( nTime, false ).." on Day "..nDay )
